<?php require_once('header.php'); ?>

<?php
if(isset($_POST['form1'])) {
    $valid = 1;

    if(empty($_POST['caption'])) {
        $valid = 0;
        $error_message .= "Photo Caption Name can not be empty<br>";
    }

    // Check if files were uploaded
    if(empty($_FILES['photos']['name'][0])) {
        $valid = 0;
        $error_message .= "You must select at least one photo<br>";
    }

    if($valid == 1) {
        // Loop through each uploaded file
        foreach($_FILES['photos']['tmp_name'] as $key => $tmp_name) {
            $path = $_FILES['photos']['name'][$key];
            $path_tmp = $_FILES['photos']['tmp_name'][$key];

            $ext = pathinfo($path, PATHINFO_EXTENSION);
            
            if($ext != 'jpg' && $ext != 'png' && $ext != 'jpeg' && $ext != 'gif') {
                $error_message .= 'File ' . $path . ' must be jpg, jpeg, gif or png<br>';
                continue;
            }

            // Generate a unique filename
            $final_name = 'photo-' . uniqid() . '.' . $ext;
            move_uploaded_file($path_tmp, '../assets/uploads/' . $final_name);

            // Save to database
            $statement = $pdo->prepare("INSERT INTO tbl_photo (caption, photo) VALUES (?,?)");
            $statement->execute(array($_POST['caption'], $final_name));
        }

        $success_message = 'Photos are added successfully.';
    }
}
?>

<section class="content-header">
    <div class="content-header-left">
        <h1>Add Photo</h1>
    </div>
    <div class="content-header-right">
        <a href="photo.php" class="btn btn-primary btn-sm">View All</a>
    </div>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php if(isset($error_message)): ?>
            <div class="callout callout-danger">
                <p><?php echo $error_message; ?></p>
            </div>
            <?php endif; ?>

            <?php if(isset($success_message)): ?>
            <div class="callout callout-success">
                <p><?php echo $success_message; ?></p>
            </div>
            <?php endif; ?>

            <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                <div class="box box-info">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="" class="col-sm-2 control-label">Photo Caption <span>*</span></label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" name="caption">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-sm-2 control-label">Upload Photos <span>*</span></label>
                            <div class="col-sm-4" style="padding-top:6px;">
                                <input type="file" name="photos[]" multiple>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-sm-2 control-label"></label>
                            <div class="col-sm-6">
                                <button type="submit" class="btn btn-success pull-left" name="form1">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>

<?php require_once('footer.php'); ?>